"""Repository validation scripts."""
