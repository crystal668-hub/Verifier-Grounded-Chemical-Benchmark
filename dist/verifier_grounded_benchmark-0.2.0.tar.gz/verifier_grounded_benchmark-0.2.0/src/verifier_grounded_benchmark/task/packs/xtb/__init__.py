"""xTB task-pack resources."""
