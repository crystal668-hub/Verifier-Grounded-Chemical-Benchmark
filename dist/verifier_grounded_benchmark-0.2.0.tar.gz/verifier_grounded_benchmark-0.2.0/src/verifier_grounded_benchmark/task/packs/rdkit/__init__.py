"""RDKit task-pack resources."""
