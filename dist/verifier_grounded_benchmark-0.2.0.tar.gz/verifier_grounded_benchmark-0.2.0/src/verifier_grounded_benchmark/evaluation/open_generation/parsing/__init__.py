"""Open-generation candidate parsers."""
