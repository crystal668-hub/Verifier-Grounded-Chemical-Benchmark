"""Property Calculation answer parsers."""
